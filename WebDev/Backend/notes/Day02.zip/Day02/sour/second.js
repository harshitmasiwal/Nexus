
function sum(a,b){
    console.log(a+b);
}

export default sum;

