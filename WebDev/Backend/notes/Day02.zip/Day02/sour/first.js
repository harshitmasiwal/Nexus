import sum from "./second.js";
// import
//  import
//  import


sum(3,8);

console.log("Hello Ji");