const sum = require("./sum")
const sub = require("./sub")
const mul = require("./mul")


module.exports = {sum,sub,mul};