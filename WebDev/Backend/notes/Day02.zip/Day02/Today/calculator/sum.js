
function sum(a,b){
    console.log(a+b);
}

module.exports = sum;