function sub(a,b){
    console.log(a-b);
}

module.exports = sub;