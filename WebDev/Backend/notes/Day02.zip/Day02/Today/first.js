const {sum, sub, mul} = require("./calculator");

sum(2,4);
sub(3,4);
mul(6,8);

console.log("Hello ji");