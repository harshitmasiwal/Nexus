

// a = "Rohit";

// Number
let a:number = 10;
let b:number = 20;

// string
let str:string = "Rohit";

// boolean
let isExist:boolean = true;
isExist = false;

// bigint
// let bignumber:bigint = 132143292183n;

// null
let abc:null = null;
let bcd:undefined=undefined;
// bcd = "Mohan";

let names:string = "Moahn";
let honey:number = 20;

const ho:number = 17;


// Compile time language
// Interprted language
// JIT: Just in time

let x = 20;
x = "rohit";