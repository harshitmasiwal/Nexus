"use strict";
// a = "Rohit";
// Number
let a = 10;
let b = 20;
// string
let str = "Rohit";
// boolean
let isExist = true;
isExist = false;
// bigint
// let bignumber:bigint = 132143292183n;
// null
let abc = null;
let bcd = undefined;
// bcd = "Mohan";
let names = "Moahn";
let honey = 20;
const ho = 17;
// Compile time language
// Interprted language
// JIT: Just in time
let x = 20;
