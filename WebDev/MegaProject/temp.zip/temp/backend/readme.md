making of the route by which logged in user can see all the submissions that he made of a particular problem by giving the problem id

also leaned about the compound index using the mongodb and used it in the submission model
and also implemented the user delete feature in 

and also the ratelimiter which allows the user to run the 1 sumbission in 10 seconds

