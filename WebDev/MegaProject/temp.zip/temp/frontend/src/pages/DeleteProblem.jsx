import React from 'react'

const DeleteProblem = () => {
  return (
    <div>
      delete
    </div>
  )
}

export default DeleteProblem
