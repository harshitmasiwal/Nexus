import React from 'react'

const UpdateProblem = () => {
  return (
    <div>
      update
    </div>
  )
}

export default UpdateProblem
