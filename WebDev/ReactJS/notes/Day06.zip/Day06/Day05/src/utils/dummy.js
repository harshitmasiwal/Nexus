const arr = [{cloth:"Tshirt", Offer:"20-40%Off" , price:200},{cloth:"Pant", Offer:"30-50%Off",price:2000},{cloth:"Skirt", Offer:"10-20%Off",price:1100},{cloth:"Kurta", Offer:"30-60%Off",price:400},{cloth:"Patloon", Offer:"11-40%Off",price:500},{cloth:"Shoes", Offer:"40-60%Off",price:2200},{cloth:"Shirt", Offer:"10-20%Off",price:1400},{cloth:"Bag", Offer:"15-40%Off",price:600}]

export function greet(){
    return <h1>Hello Coder Army</h1>
}

export function meet(){
    return <h1>Hello Bhaiya ji</h1>
}

export default arr;
