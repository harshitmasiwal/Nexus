export default function Hi(){

    return(
        <h1>I am Hi</h1>
    )
}