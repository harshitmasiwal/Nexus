
function Header(){
    return(
        <>
          <div id="heading">
            <h1>Github Profile Viewer</h1>
          </div>
        </>
    )
}

export default Header;