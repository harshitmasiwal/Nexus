<!-- ****************************************************** -->
1: Color

<!-- bg-red-500 -->
color intensity: 50 to 950

<!-- green orange sky blue -->
<!-- white and black don't have any intensity -->

<!-- text-color-intensity -->


<!-- ****************************************************** -->
2: Border

<!-- border --> It will add default border with size 1px
<!-- border-2 --> 2px border
<!-- border-color-intensity -->

<!-- border-t, border-r, border-b, border-l -->
top, right botton left
<!-- border-t-2 --> border top 2px




<!-- ****************************************************** -->
3: Margin
<!-- m-1 --> here 1 points to 4px , 0.25rem, margin of 4px on all side
<!-- mx-1 --> horizontal margin
<!-- my-1 --> vertical margin
<!-- mt mb ml mr -->





<!-- ****************************************************** -->
4: Padding
<!-- p-1 --> here 1 points to 4px, padding of 4px on all side: 16px === 1rem
<!-- px-1 --> Horizontal padding
<!-- py-1 --> Vertical padding
<!-- pt pb pl pr -->







<!-- ****************************************************** -->


Class	    Font Size (rem)	  Font Size (px)
text-xs	    0.75rem	          12px
text-sm	    0.875rem	      14px
text-base	1rem	          16px (default)
text-lg	    1.125rem	      18px
text-xl	    1.25rem	          20px
text-2xl	1.5rem	          24px
text-3xl	1.875rem	      30px
text-4xl	2.25rem	          36px
text-5xl	3rem	          48px





<!--  <img className="w-full h-48 object-cover rounded-xl"  -->

border-radius

rounded
xs, sm, md, lg, xl, 2xl,