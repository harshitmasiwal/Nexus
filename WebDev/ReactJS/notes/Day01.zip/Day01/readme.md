<!-- How to create your own library -->
<!-- What is CDN -->
<!-- How to bring React and React DOM -->

<!-- const element  = React.createElement("h1",{id:"money", class:"Rohit" , style:{fontSize:"20px",backgroundColor:"blue",color:"red"}},"Hello Coder Army");

const root = ReactDOM.createRoot(document.getElementById('root'));


root.render(element); -->