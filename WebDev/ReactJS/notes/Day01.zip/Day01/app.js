const element = React.createElement("h1",{},"Hello Coder Army");

// ReactDOM.render(element,document.getElementById('root'));
// element : 50 card pade hue hai

const Reactroot = ReactDOM.createRoot(document.getElementById('root'));
// React root container: is
Reactroot.render(element);