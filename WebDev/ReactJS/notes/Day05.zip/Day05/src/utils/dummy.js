const arr = [{cloth:"Tshirt", Offer:"20-40%Off"},{cloth:"Pant", Offer:"30-50%Off"},{cloth:"Skirt", Offer:"10-20%Off"},{cloth:"Kurta", Offer:"30-60%Off"},{cloth:"Patloon", Offer:"11-40%Off"},{cloth:"Shoes", Offer:"40-60%Off"},{cloth:"Shirt", Offer:"10-20%Off"},{cloth:"Bag", Offer:"15-40%Off"}]

export function greet(){
    return <h1>Hello Coder Army</h1>
}

export function meet(){
    return <h1>Hello Bhaiya ji</h1>
}

export default arr;
