const state = {
    slice1:{
        count:0
    },
    slice2:{
        count:2,
        name:"Rohit"
    },
    slice3:{
        login:true,
    }
}


// actions: {type: "slice/Increment" , payload: undefined}