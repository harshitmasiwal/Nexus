export default function Dashboard(){

    return(
        <h1>Welcome to Our Dashboard</h1>
    )
}