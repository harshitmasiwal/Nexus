export default function Contact(){

    return(
        <h1>Welcome to Contact Page</h1>
    )
}