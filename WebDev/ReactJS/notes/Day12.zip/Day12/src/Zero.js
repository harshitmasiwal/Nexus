export default function Zero(){

    return(
        <>
        <h1>Welcome to Details Page</h1>
        <h1>I am Zero</h1>
        </>
    )
}