export default function Hello(){

    return(
        <h1>I am Hello</h1>
    )
}