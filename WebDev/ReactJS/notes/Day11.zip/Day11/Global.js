import { createContext } from "react";

const GlobalContext =  createContext("Rohit");

export default GlobalContext;