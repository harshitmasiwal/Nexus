import Third from "./Third"
import GlobalContext from "./Global"
import { useCallback, useContext } from "react"

export default function Second(){
    

    return (
        <>
         <h2>Kaise hai aap sab log</h2>
         <Third/>
        </>

    )
}