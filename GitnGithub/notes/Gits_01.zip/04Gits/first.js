const name = "ROhit";
const age = 23;

let balance = 420;

function updateBalance(value){
    balance+=value;
}


console.log("Hello Coders");

console.log("Hello Ji");


const c = 20+10;
console.log(c);

function balancechecker(){
    // 
    console.log("UPdate");
    // 
}


//  code likho
//  5 member code likh rhe hai
// update code: 
// 3 line of code