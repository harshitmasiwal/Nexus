const button = "Added a Button";
console.log(button);

const login = "Login page added";
console.log(login);

const footer = "Footer added in our website";
console.log(footer);
const Payment = "Integrated the payment gateway";
console.log(Payment);

const upi = "Integrated the UPI";
console.log(upi);

console.log("Latest Update");

// I am fixing some Bug
console.log("Bug Fixed");