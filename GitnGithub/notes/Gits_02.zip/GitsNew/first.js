const name = "Rohit";
const age = 90;
const balance = 300;

console.log("Hello");
function updateBalance(){
    balance+=20;
}

updateBalance();

console.log(balance);

console.log("Money honey");
console.log("Bug final commit");
console.log("Mein hu hero tera");

function showage(val){
    console.log(age+val);
}

showage(10);
function showName(){
    console.log(name);
}

showName();